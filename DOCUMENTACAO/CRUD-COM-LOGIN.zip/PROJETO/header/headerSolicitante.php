<header>
<nav class="navbar navbar-expand-lg navbar-light bg-dark">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="inicialSolicitante.php">
            <img src="../assets/img/chamuzeLogoComFundoR.png" alt="Logo Chamauze" class="rounded-3" width="240">
        </a>

        <!-- Botões da Navbar -->
        <div class="d-flex">
            <a class="btn btn-outline-warning me-2" href="../solicitante/visualizarServicos.php">Meus Serviços</a>
            <a class="btn btn-outline-warning me-2" href="#">Bate-papo</a>
            <a class="btn btn-warning" href="#">Perfil</a>
        </div>
    </div>
</nav>
</header>