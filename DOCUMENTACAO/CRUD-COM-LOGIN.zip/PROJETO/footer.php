<footer class="bg-dark text-white text-center py-3 mt-auto">
    © 2025 Chamauze - Todos os direitos reservados
</footer>